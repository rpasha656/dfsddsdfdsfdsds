import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DocpubComponent, UploadComponent, CategoryEdit } from './index';
const DocpubRoutes: Routes = [
  {
    path: '', component: DocpubComponent
  },
  {
    path: 'docpub', component: DocpubComponent
  },
  { path: 'upload', component: UploadComponent },
  { path: 'upload/:planname', component: UploadComponent },
  { path: 'categoryedit', component: CategoryEdit }
];

@NgModule({
  declarations: [
  ],
  imports: [RouterModule.forChild(DocpubRoutes)],
  exports: [RouterModule],
  providers: []
})
export class DocpubRoutingModule { }

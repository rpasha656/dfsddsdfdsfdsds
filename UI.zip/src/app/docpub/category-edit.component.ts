import { Component } from '@angular/core';
import { FileMetadataService, FileMetadataListing, SubCategories } from './index';
@Component({
    selector: 'as-edit-category',
    template: require('./category-edit.component.html')
})
export class CategoryEdit {
    public tableData = [];
    public Category = '';
    public oldText = '';
    public oldSubcategory = '';
    // public subCategories = [];
    public selectedCategory = {};
    public subCategories: SubCategories[];
    public subJsonData: Object[];
    public category: FileMetadataListing[];
    constructor(private filemetadataService: FileMetadataService) {
        this.filemetadataService.getCategories().subscribe(res => this.loadCategory(res));
    }
    loadCategory(data: any) {
        this.tableData = data;
        this.selectedCategory = this.tableData[0].subCategories;
        /*let keyName = 'subCategories';*/
        this.subCategories = this.selectedCategory[0].subCategories;
    }
    addCategory() {
        let obj = {
            'editable': false,
            'name': this.Category,
            'subCategories': [],
            'showSubcategory': true
        };
        this.tableData.push(obj);
        this.Category = '';
        this.selectedCategory = this.tableData[this.tableData.length - 1];
        let keyName = 'subCategories';
        this.subCategories = this.selectedCategory[keyName];
    }
    addSubCategory(row, id) {
        if (this.selectedCategory.hasOwnProperty('name')) {
            let eleId: string = 'addSubcategory';
            let inputValue = (<HTMLInputElement>document.getElementById(eleId)).value;
            if (inputValue.length > 0) {
                let obj = {
                    'editable': false,
                    'name': inputValue
                };
                let index = this.tableData.indexOf(this.selectedCategory);
                let keyName = 'subCategories';
                this.tableData[index][keyName].push(obj);
                (<HTMLInputElement>document.getElementById(eleId)).value = '';
            }
        } else {
            let eleId: string = 'addSubcategory';
            (<HTMLInputElement>document.getElementById(eleId)).value = '';
        }
    }
    deleteCategory(row) {
        let index = (this.tableData.indexOf(row));
        if (index > -1) {
            this.tableData.splice(index, 1);
            this.subCategories = [];
            this.selectedCategory = {};
        }
    }
    deleteSubCategory(row) {
        let index = this.subCategories.indexOf(row);
        if (index > -1) {
            this.subCategories.splice(index, 1);
        }
    }

    enableSubCategory(row) {
        let index = this.tableData.indexOf(row);
        this.selectedCategory = this.tableData[index];
        this.subCategories = this.tableData[index].subCategories;
    }

    beginEdit(el: HTMLElement, index: string): void {
        this.oldText = this.tableData[index].name;
        this.tableData[index].editable = true;
    }
    beginsubCategoryEdit(el: Object, indexCat: string): void {
        let subcategory: any = this.subCategories;
        let index = (subcategory.indexOf(el));
        if (index > -1) {
            this.oldSubcategory = subcategory[index].name;
            subcategory[index].editable = true;
        }
    }
    editDone(newText, index: string): void {
        newText.editable = false;
    }
    editsubCategoryDone(row, indexCat: string): void {
        let subcategory: any = this.subCategories;
        let index = (subcategory.indexOf(row));
        if (index > -1) {
            subcategory[index].editable = false;
        }
    }
    editCancel(newText, index: string): void {
        console.log('edit cancel');
        newText.name = this.oldText;
        newText.editable = false;
        this.oldText = '';
    }
    editsubCategoryCancel(newText, indexCat: string): void {
        newText.name = this.oldSubcategory;
        newText.editable = false;
        this.oldSubcategory = '';
    }
    addCategoriesToDatabase() {

    }

}



